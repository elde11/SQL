Skorzystaj z bazy `simple_library_db.csv`

---

1. Podaj listę wszystkich książek w bibliotece
2. Podaj listę książek napisanych przez Stanisława Lema
3. Podaj listę książek zarejestrowanych w 2015 r.
4. Oblicz liczbę książek w bibliotece
5. Oblicz, ilu różnych autorów stworzyło książki przechowywane w bibliotece
6. Dla każdego autora oblicz liczbę egzemplarzy książek przechowywanych w bibliotece
7. Oblicz liczbę książek starszych niż 10 lat
8. Dla każdego autora podaj liczbę tytułów przez niego napisanych